#!/usr/bin/python
print('Hola Mundo')
