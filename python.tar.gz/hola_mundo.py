#!/usr/bin/python

import argparse

parser = argparse.ArgumentParser()
parser.add_argument('-n', '--name', required=True)

args = parser.parse_args()
name = args.name


print('Hola', name)
